/* ---------------------------------------------------------------------- /
	Pricer2 - CSS3 Pricing Grid (jQuery fallback plugin)
	author: pixelboi8 (pixelboi8@gmail.com)
	All rights reserved.
	v1.0 - 10/07/2011
/ ---------------------------------------------------------------------- */
(function($){
	$.fn.pricer2 = function() {
		if (!isTransitionSupported()) {	
			return this.each(function(index) {
				var obj = $(this);
				obj.delegate('div.col:not([class*="selected"])', 'hover', function(event){
					var span = $(this).children('span');
					if(event.type === 'mouseenter') {
						span.css('display','none').fadeIn(500);
					} else {
						span.css({'visibility':'visible', 'opacity':0.9}).fadeOut(500);
					};
				});
				obj.delegate('.tooltip', 'hover', function(){
					var tip = $(this).find('.tip');
						tip.css('display','none').fadeIn(400);
				});				
			});
		};
	};	
	
	isTransitionSupported = function() {
    var elem = document.createElement('div');
    var elemStyle = elem.style;
	var support = elemStyle.transition !== undefined || elemStyle.WebkitTransition !== undefined || elemStyle.MozTransition !== undefined || elemStyle.MsTransition !== undefined || elemStyle.OTransition !== undefined;
	if (support) {return true} else {return false};
};	
})(jQuery);		