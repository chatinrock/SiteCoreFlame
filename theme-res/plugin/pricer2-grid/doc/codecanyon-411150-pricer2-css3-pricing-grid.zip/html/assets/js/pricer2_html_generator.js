/* ---------------------------------------------------------------------- /
	Pricer2 - CSS3 Pricing Grid (html generator js)
	author: pixelboi8 (pixelboi8@gmail.com)
	All rights reserved.
	v1.0 - 10/07/2011
/ ---------------------------------------------------------------------- */
$(document).ready(function(){
	//** [ GENERAL ] **//
	var pricer;
	var col;
	var colSettings=$('#col-settings');
	var preview=$('#preview');
	var htmlCode=$('#html-code');
	var boxes=[];
	boxes[boxes.length++]=colSettings[0];
	boxes[boxes.length++]=preview[0];
	boxes[boxes.length++]=htmlCode[0];	

	//** [ EVENTS ] **//	
	// Create & modify button
	$('#create').bind('click', function() {
		$(this)[0].innerHTML='modify';
		for (var i=0;i<boxes.length;i++) { document.getElementById(boxes[i].id).style.display = 'block'; };
		var colNum=$('#colnum')[0].value;
		var rowNum=$('#rownum')[0].value;
		updateContainer(colNum);
		updateCol(colNum, rowNum);
		updateGenerator(colNum, rowNum);
		updateCode();
	});
	// Reset button	
	$('#reset').bind('click', function() {
		$('#create')[0].innerHTML='create';
		$('#colnum option').filter('[value=1]')[0].selected = true;
		$('#rownum option').filter('[value=1]')[0].selected = true;
		for (var i=0;i<boxes.length;i++) { document.getElementById(boxes[i].id).style.display = 'none'; };
	});
	// Show & hide box content
	$('h2').bind('click', function() {
		var obj=$(this).find('a');
		obj.toggleClass('show');
		obj.parent().next().toggle(0);
	});	
	// Modify color
	colSettings.delegate('.color', 'change', function(){
		var obj=$(this);
		var index=colSettings.find('.color').index(obj);
		col.eq(index)[0].className='col '+obj[0].value;
		updateCode();
	});
	// Modify ribbon
	colSettings.delegate('.ribbon', 'change', function(){
		var pObj=col.find('.header');
		var cObj=$(this);
		var index=colSettings.find('.ribbon').index(cObj);
 		var prObj=pObj.eq(index).find('.ribbon');
		 if (cObj[0].value=='0') {
			if (prObj.length>0) { prObj.remove(); };
		 } else {
			 if (prObj.length==0) { pObj.eq(index).prepend('\n\t\t\t<div class="ribbon"></div>'); };
			 pObj.eq(index).find('.ribbon')[0].className='ribbon '+cObj[0].value;
		 };
		 updateCode();
	});	
	// Modify selected
	colSettings.delegate('.selected', 'change', function(){
		var obj=$(this);
		var index=colSettings.find('.selected').index(obj);
		col.eq(index).toggleClass('selected');
		updateCode();
	});	
	// Modify Product
	colSettings.delegate('.product', 'change', function(){
		var pObj=col.find('.product');
		var cObj=$(this);
		var index=colSettings.find('.product').index(cObj);
		pObj.eq(index)[0].innerHTML=cObj[0].value;
		updateCode();
	});
	// Modify Price
	colSettings.delegate('.price', 'change', function(){
		var pObj=col.find('.amount');
		var cObj=$(this);
		var index=colSettings.find('.price').index(cObj);
		pObj.eq(index)[0].innerHTML=cObj[0].value;
		updateCode();
	});	
	// Modify payment
	colSettings.delegate('.payment', 'change', function(){
		var pObj=col.find('.payment');
		var cObj=$(this);
		var index=colSettings.find('.payment').index(cObj);
		pObj.eq(index)[0].innerHTML=cObj[0].value;
		updateCode();
	});	
	// Modify details content
	colSettings.delegate('.details .textbox', 'change', function(){
		var pObj=col.find('li');
		var cObj=$(this);
		var index=colSettings.find('.details .textbox').index(cObj);
		pObj.eq(index)[0].innerHTML=cObj[0].value;
		updateCode();
	});
	// Add & remove tooltip
	colSettings.delegate('.tip', 'change', function(){
		var pObj=col.find('li');
		var cObj=$(this);
		var index=colSettings.find('.tip').index(cObj);
		if (cObj[0].value=='') {
			if (pObj.eq(index).hasClass('last')) {
				pObj.eq(index).removeClass('tooltip');
			} else  {
				pObj.eq(index)[0].removeAttribute('class');
			};
			var tip=pObj.eq(index).find('.tip');
			if (tip.length>0) { tip.remove(); };
		} else {
			pObj.eq(index).addClass('tooltip');
			pObj.eq(index).append('<span class="tip">'+cObj[0].value+'</span>');
		};
		updateCode();
	});	
	// Modify signup button content
	colSettings.delegate('.signup .textbox', 'change', function(){
		var pObj=col.find('.signup a strong');
		var cObj=$(this);
		var index=colSettings.find('.signup .textbox').index(cObj);
		pObj.eq(index)[0].innerHTML=cObj[0].value;
		updateCode();
	});		

	//** [ FUNCTIONS ] **//
	// Create & modify pricer container
	updateContainer = function(colNum) {
		var obj=$('#pricer2');
		var cName='';
		if (colNum>1) { cName='p'+colNum+'cols'; };
		if (obj.length==0) {
			if (colNum>1) {
				preview.find('.content').html('<div id="pricer2" class="'+cName+'">\n</div>');
			} else {
				preview.find('.content').html('<div id="pricer2">\n</div>');
			};
		} else { 
			obj[0].className=cName;
			if (obj[0].className=='') { obj[0].removeAttribute('class'); };
		};
		pricer=$('#pricer2');
		updateCode();
	};
	// Create & modify pricer cols
	updateCol = function(colNum, rowNum) {
		var obj=pricer.find('.col');
		var htmlCode='';
		for (var i=0;i<colNum-obj.length;i++) { htmlCode+='\t<div class="col blue1"><span></span>\n\t\t<div class="header">\n\t\t\t<div class="product">Product</div>\n\t\t\t<div class="price">\n\t\t\t\t<p class="amount">$9</p>\n\t\t\t\t<p class="payment">monthly</p>\n\t\t\t</div>\n\t\t</div>\n\t\t<ul>\n</ul>\n\t\t<div class="signup"><a href="#"><span></span><strong>signup</strong></a></div>\n\t</div>\n\t<div class="clearfix"></div>\n'; };
		pricer.append(htmlCode).find('.clearfix').not(':last').remove();
		if (obj.length>colNum) {
			for (var x=0;x<obj.length;x++) {
				if (x>colNum-1) { obj[0].parentNode.removeChild(obj[x]); };
			};
		};
		col=pricer.find('.col'); // update cols
		var objUl=pricer.find('ul');
		for (var i=0;i<objUl.length;i++) {	
			var objUlCurrent=$(objUl[i]);
			var objLi=objUlCurrent.find('li');
			if (objLi.length>0) { 
				htmlCode=''; 
			} else {
				htmlCode='\t\t';	
			};
			for (var x=0;x<rowNum-objLi.length;x++) { htmlCode+='\t<li class="last"><strong>lorem</strong> ipsum</li>\n\t\t'; };
			objUlCurrent.append(htmlCode);
			if (objLi.length>rowNum) {
				for (var x=0;x<objLi.length;x++) {
					if (x>rowNum-1) { objLi[0].parentNode.removeChild(objLi[x]); };
				};				
			};
			objLi=objUlCurrent.find('li');
			for (var x=0;x<objLi.length;x++) {
				if (x<objLi.length-1 && objLi[x].className.match(/\blast\b/)) {	objLi[x].className=objLi[x].className.replace(/\blast\b/,'').replace(/^\s*/, '').replace(/\s*$/, ''); };				
				if (x==objLi.length-1 && objLi[x].className.match(/\blast\b/)==null) { 
					objLi[x].className+=' last';
					objLi[x].className=objLi[x].className.replace(/^\s*/, '').replace(/\s*$/, '');
				};
				if (objLi[x].className=='') { objLi[x].removeAttribute('class'); };			
			};
		};
		updateCode();
	};	
	// Show html source	
	updateCode = function() {
		htmlCode.find('pre').text(preview.find('.content').html());
		var removable=htmlCode.find('pre').text();
		removable=removable.replace(/\t\t\t\n/g, '').replace(/\t\n/g, '');
		htmlCode.find('pre').text(removable);
	};	
	// Create & modify generator cols
	updateGenerator = function(colNum, rowNum) {
		var obj=colSettings.find('.col');
		var htmlCode='';
		for (var i=0;i<colNum-obj.length;i++) {
			htmlCode+='<div class="col"><p><strong>general settings</strong></p><ul><li><span>color</span><select class="color textbox"><optgroup label="blue colorset"><option value="blue1">blue1</option><option value="blue2">blue2</option><option value="blue3">blue3</option><option value="blue4">blue4</option><option value="blue5">blue5</option></optgroup><optgroup label="green colorset"><option value="green1">green1</option><option value="green2">green2</option><option value="green3">green3</option><option value="green4">green4</option><option value="green5">green5</option></optgroup><optgroup label="orange colorset"><option value="orange1">orange1</option><option value="orange2">orange2</option><option value="orange3">orange3</option><option value="orange4">orange4</option><option value="orange5">orange5</option></optgroup><optgroup label="red colorset"><option value="red1">red1</option><option value="red2">red2</option><option value="red3">red3</option><option value="red4">red4</option><option value="red5">red5</option></optgroup></select></li><li><span>ribbon</span><select class="ribbon textbox"><option value="0">none</option><option value="featured">featured</option><option value="best-value">best value</option></select></label></li><li><span>selected</span><input class="selected" type="checkbox" value="1" /></li></ul><p><strong>Product</strong></p><ul><li><span>name</span><input type="text" class="product textbox" value="Product" /></li><li><span>price</span><input type="text" class="price textbox" value="$9" /></li><li><span>payment</span><input type="text" class="payment textbox" value="monthly" /></li><li></li></ul><p><strong>details</strong></p><ul class="details"></ul><p><strong>button text</strong></p><ul class="signup"><li><span>text</span><input type="text" class="textbox" value="signup" /></li></ul></div>';
			};
		colSettings.find('.content').append(htmlCode);
		if (obj.length>colNum) {
			for (var i=0;i<obj.length;i++) {
				if (i>colNum-1) { obj[0].parentNode.removeChild(obj[i]); };
			};
		};
		var objUl=colSettings.find('.details');
		for (var i=0;i<objUl.length;i++) {			
			var objUlCurrent=$(objUl[i]);
			var objLi=objUlCurrent.find('li');
			var htmlCode='';
			for (var x=0;x<rowNum-objLi.length;x++) { htmlCode+='<li><input type="text" class="textbox w75" value="<strong>lorem</strong> ipsum" /><span class="tooltip">tooltip</span><input type="text" class="tip w75" value="" /></li>'; };
			objUlCurrent.append(htmlCode);
			if (objLi.length>rowNum) {
				for (var x=0;x<objLi.length;x++) {
					if (x>rowNum-1) { objLi[0].parentNode.removeChild(objLi[x]); };
				};								
			};
		};
	};
});